import { motion } from "framer-motion";
import { ArrowRight, MessageSquare, Zap, BarChart3 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const automations = [
  {
    icon: <MessageSquare className="w-10 h-10 text-[hsl(var(--primary))]" />,
    title: "WhatsApp Lead Bot",
    description: "Automated lead qualification and booking system that responds 24/7 on WhatsApp, qualifying prospects and scheduling calls automatically.",
    useCase: "Service businesses, consulting firms"
  },
  {
    icon: <Zap className="w-10 h-10 text-blue-500" />,
    title: "Email & CRM Automation",
    description: "Smart workflows that sync contacts, send personalized follow-ups, and nurture leads through your sales pipeline automatically using Zapier/Make.",
    useCase: "Sales teams, agencies, e-commerce"
  },
  {
    icon: <BarChart3 className="w-10 h-10 text-purple-500" />,
    title: "Data & Reporting Automation",
    description: "Connect your business tools to automatically track metrics, generate reports, and send insights to your team daily.",
    useCase: "Marketing teams, agencies, SaaS"
  }
];

export function Automation() {
  return (
    <section id="automation" className="py-24 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="mb-16 max-w-3xl">
          <h2 className="text-4xl md:text-5xl font-bold font-heading mb-6 text-gray-900">
            Business Automation Solutions
          </h2>
          <p className="text-xl text-gray-600">
            Stop wasting time on repetitive tasks. We build intelligent automation systems that save your team hours every week and streamline business workflows.
          </p>
          <span className="hidden">Business automation | Workflow automation | AI automation | Zapier automation | WhatsApp bot | CRM automation | Business process automation</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {automations.map((automation, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="h-full border-none shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white group overflow-hidden relative p-2">
                <div className="absolute top-0 left-0 w-1 h-full bg-gray-100 group-hover:bg-[hsl(var(--primary))] transition-colors duration-300" />
                <CardHeader>
                  <div className="mb-4 p-3 rounded-xl bg-gray-50 w-fit group-hover:scale-110 transition-transform duration-300">
                    {automation.icon}
                  </div>
                  <CardTitle className="text-2xl font-bold">{automation.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-base text-gray-600 leading-relaxed mb-4">
                    {automation.description}
                  </p>
                  <div>
                    <Badge variant="outline" className="text-xs">
                      {automation.useCase}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-black text-white p-10 rounded-2xl text-center"
        >
          <h3 className="text-3xl font-bold mb-4">Custom Automation Available</h3>
          <p className="text-gray-300 text-lg mb-6 max-w-2xl mx-auto">
            Every business is unique. Let's discuss your specific automation needs and build a solution that saves you time and money.
          </p>
          <button 
            onClick={() => window.open('https://calendly.com/lead-generation-website/30min', '_blank')}
            className="inline-flex items-center gap-2 bg-[hsl(var(--primary))] text-black font-bold px-8 py-4 rounded-full hover:bg-emerald-500 transition-colors"
          >
            Book Automation Consultation <ArrowRight className="w-5 h-5" />
          </button>
        </motion.div>
      </div>
    </section>
  );
}
