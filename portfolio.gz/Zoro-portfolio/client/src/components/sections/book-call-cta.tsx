import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Calendar, MessageCircle } from "lucide-react";

export function BookCallCTA() {
  return (
    <section className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold font-heading mb-6 text-gray-900">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-gray-600 mb-12 leading-relaxed">
            Choose your preferred way to connect with me. Let's discuss your project and bring your vision to life.
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Button
              size="lg"
              className="rounded-full bg-[hsl(var(--primary))] text-black hover:bg-emerald-500 px-8 py-6 font-bold text-lg inline-flex items-center gap-2"
              onClick={() => window.open('https://wa.me/919324318917', '_blank')}
              data-testid="button-whatsapp-cta"
            >
              <MessageCircle className="w-5 h-5" />
              Chat on WhatsApp
            </Button>

            <Button
              size="lg"
              className="rounded-full bg-[hsl(var(--primary))] text-black hover:bg-emerald-500 px-8 py-6 font-bold text-lg inline-flex items-center gap-2"
              onClick={() => window.open('https://calendly.com/lead-generation-website/30min', '_blank')}
              data-testid="button-book-call-cta"
            >
              <Calendar className="w-5 h-5" />
              Book a Call
            </Button>
          </div>

          <p className="text-sm text-gray-500 mt-8">
            Quick response time • Free consultation • No obligations
          </p>
        </motion.div>
      </div>
    </section>
  );
}
