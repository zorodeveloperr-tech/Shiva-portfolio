import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Star } from "lucide-react";
import { motion } from "framer-motion";

const testimonials = [
  {
    name: "Sarah J.",
    role: "Marketing Director",
    content: "Incredible speed and quality. The website was live in 3 weeks and looks better than competitors charging double. Communication was flawless throughout.",
    stars: 5
  },
  {
    name: "Mark T.",
    role: "Business Owner",
    content: "The AI automation setup completely transformed our lead process. We're closing more deals with less manual work. Real results, fast.",
    stars: 5
  },
  {
    name: "Elena R.",
    role: "Founder",
    content: "Finally, an agency that understands both design and functionality. The support has been amazing even after launch. Highly recommended.",
    stars: 5
  }
];

export function Testimonials() {
  return (
    <section className="py-24 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl font-bold font-heading mb-6 text-gray-900">
            What Clients Say
          </h2>
          <p className="text-xl text-gray-600">
            We prioritize speed, quality, and clear communication.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="h-full border-none shadow-sm hover:shadow-md transition-shadow p-6">
                <CardHeader className="p-0 mb-4">
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.stars)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-[hsl(var(--primary))] text-[hsl(var(--primary))]" />
                    ))}
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <p className="text-gray-700 text-lg mb-6 leading-relaxed italic">
                    "{testimonial.content}"
                  </p>
                  <div>
                    <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
