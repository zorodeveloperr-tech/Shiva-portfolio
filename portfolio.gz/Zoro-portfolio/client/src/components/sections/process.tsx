import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

const steps = [
  {
    number: "01",
    title: "Discovery",
    description: "We discuss your business goals, target audience, and requirements to understand exactly what you need."
  },
  {
    number: "02",
    title: "Planning",
    description: "I create a clear roadmap and structure for your website or automation system to ensure we hit every goal."
  },
  {
    number: "03",
    title: "Build & Review",
    description: "I develop your custom solution, keeping you updated with regular previews and incorporating your feedback."
  },
  {
    number: "04",
    title: "Launch & Support",
    description: "We go live! I ensure everything runs perfectly and provide ongoing support to help you scale."
  }
];

export function Process() {
  return (
    <section id="process" className="py-24 bg-black text-white overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-start">
          <div className="lg:w-1/3 lg:sticky lg:top-32">
            <h2 className="text-4xl md:text-5xl font-bold font-heading mb-6">
              Our Process
            </h2>
            <p className="text-xl text-gray-400 mb-8">
              A simplified, proven 4-step methodology to take your project from concept to reality efficiently.
            </p>
            <div className="p-6 rounded-2xl bg-gray-900 border border-gray-800">
              <h4 className="font-bold text-lg mb-4 flex items-center gap-2">
                <CheckCircle2 className="text-[hsl(var(--primary))]" /> Key Benefits
              </h4>
              <ul className="space-y-3 text-gray-400">
                <li>• Clear roadmap & timelines</li>
                <li>• Regular updates & feedback</li>
                <li>• No technical jargon</li>
                <li>• Focused on ROI</li>
              </ul>
            </div>
          </div>

          <div className="lg:w-2/3 w-full">
            <div className="space-y-12">
              {steps.map((step, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, x: 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="flex flex-col md:flex-row gap-6 md:gap-10 border-b border-gray-800 pb-12 last:border-0"
                >
                  <span className="text-5xl md:text-7xl font-bold text-gray-800 font-heading">
                    {step.number}
                  </span>
                  <div>
                    <h3 className="text-2xl md:text-3xl font-bold mb-4 text-white">
                      {step.title}
                    </h3>
                    <p className="text-lg text-gray-400 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
