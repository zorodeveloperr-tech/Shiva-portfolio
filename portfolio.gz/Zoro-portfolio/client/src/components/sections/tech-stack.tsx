import { motion } from "framer-motion";

const tools = [
  "WordPress", "Elementor", "OpenAI", "Zapier", "Make", 
  "Notion", "HubSpot", "Stripe", "Python", "WooCommerce",
  "ManyChat", "Airtable"
];

export function TechStack() {
  return (
    <section className="py-16 bg-white border-y border-gray-100 overflow-hidden">
      <div className="container mx-auto px-6 mb-8 text-center">
        <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">
          Tools & Technologies We Use
        </p>
      </div>
      
      <div className="flex relative overflow-hidden">
        <motion.div 
          className="flex gap-16 items-center whitespace-nowrap"
          animate={{ x: ["0%", "-50%"] }}
          transition={{ repeat: Infinity, ease: "linear", duration: 25 }}
        >
          {[...tools, ...tools].map((tool, index) => (
            <span 
              key={index} 
              className="text-2xl md:text-4xl font-bold text-gray-300 font-heading hover:text-gray-900 transition-colors cursor-default"
            >
              {tool}
            </span>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
