import { CheckCircle, Zap, Smartphone, Search, Bot, Sliders, MessageCircle } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

const features = [
  {
    icon: <Zap className="w-6 h-6 text-[hsl(var(--primary))]" />,
    title: "Fast Delivery",
    description: "Rapid turnaround times without compromising on quality."
  },
  {
    icon: <Sliders className="w-6 h-6 text-[hsl(var(--primary))]" />,
    title: "Clean UI/UX",
    description: "Modern, intuitive designs that keep users engaged."
  },
  {
    icon: <Search className="w-6 h-6 text-[hsl(var(--primary))]" />,
    title: "SEO-Ready Builds",
    description: "Optimized structure to help you rank higher on Google."
  },
  {
    icon: <Smartphone className="w-6 h-6 text-[hsl(var(--primary))]" />,
    title: "Mobile-Responsive",
    description: "Flawless experience across all devices and screen sizes."
  },
  {
    icon: <Bot className="w-6 h-6 text-[hsl(var(--primary))]" />,
    title: "AI Chatbots",
    description: "Intelligent agents that handle support and lead gen 24/7."
  },
  {
    icon: <CheckCircle className="w-6 h-6 text-[hsl(var(--primary))]" />,
    title: "End-to-End Support",
    description: "We're with you from concept to launch and beyond."
  }
];

export function About() {
  return (
    <section id="about" className="py-24 bg-white border-b border-gray-100">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <div className="lg:w-1/2">
            <h2 className="text-4xl md:text-5xl font-bold font-heading mb-6 text-gray-900">
              About Me
            </h2>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              I'm Shiva (Zoro Developer), an AI Website & Automation Developer creating modern, mobile-first websites for global clients. I build clean, fast, conversion-focused sites with simple automations that help businesses grow while saving time. My work is direct, professional, and designed for real results.
            </p>
            <span className="hidden">Professional web developer | Website development portfolio | Automation specialist | AI solutions | Digital agency services</span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-4"
                >
                  <div className="p-2 rounded-lg bg-gray-50 shrink-0">
                    {feature.icon}
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 text-lg">{feature.title}</h4>
                    <p className="text-sm text-gray-500">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
          
          <div className="lg:w-1/2 relative">
            <div className="absolute -inset-4 bg-gradient-to-r from-[hsl(var(--primary))] to-blue-500 opacity-20 blur-2xl rounded-full" />
            <div className="relative bg-black text-white p-10 rounded-2xl shadow-2xl overflow-hidden">
              <div className="absolute top-0 right-0 p-20 bg-[hsl(var(--primary))] opacity-10 rounded-bl-full" />
              <h3 className="text-3xl font-bold mb-4">Results Driven</h3>
              <p className="text-gray-400 text-lg mb-8">
                "Our mission is to democratize enterprise-level automation and design for growing businesses."
              </p>
              <div className="flex gap-8 border-t border-gray-800 pt-8">
                <div>
                  <span className="block text-4xl font-bold text-[hsl(var(--primary))]">100%</span>
                  <span className="text-sm text-gray-400">Client Satisfaction</span>
                </div>
                <div>
                  <span className="block text-4xl font-bold text-[hsl(var(--primary))]">2x</span>
                  <span className="text-sm text-gray-400">Faster Delivery</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex justify-center mt-16"
        >
          <Button
            size="lg"
            className="rounded-full bg-[hsl(var(--primary))] text-black hover:bg-emerald-500 px-8 py-6 font-bold text-lg inline-flex items-center gap-2"
            onClick={() => window.open('https://wa.me/919324318917', '_blank')}
            data-testid="button-lets-chat"
          >
            <MessageCircle className="w-5 h-5" />
            Let's Chat
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
