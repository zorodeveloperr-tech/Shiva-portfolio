import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "What is the typical timeline for a project?",
    answer: "Most website projects are completed within 2-4 weeks, depending on complexity. Simple landing pages can be ready in as little as 3-5 days."
  },
  {
    question: "Do you offer revisions?",
    answer: "Yes! I want you to love your website. All plans include 2 rounds of major revisions during the design phase and unlimited minor tweaks before launch."
  },
  {
    question: "What about hosting and domain?",
    answer: "I can guide you through purchasing your domain and hosting. For Business and Growth plans, I handle the complete setup and connection for you."
  },
  {
    question: "Do you require a deposit?",
    answer: "Yes, a 50% deposit is required to secure your slot in my schedule and start the project. The remaining 50% is due upon successful completion and launch."
  },
  {
    question: "Can you help with content?",
    answer: "Absolutely. If you don't have images or text ready, I can use high-quality placeholder content or help you craft copy that converts."
  }
];

export function FAQ() {
  return (
    <section id="faq" className="py-24 bg-white">
      <div className="container mx-auto px-6 max-w-3xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold font-heading mb-6 text-gray-900">
            Frequently Asked Questions
          </h2>
          <p className="text-xl text-gray-600">
            Common questions about our process and services.
          </p>
        </div>

        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`}>
              <AccordionTrigger className="text-lg font-semibold text-left">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-gray-600 text-base leading-relaxed">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
