import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export function InquiryForm() {
  const [formData, setFormData] = useState({
    name: "",
    businessType: "",
    email: "",
    whatsapp: "",
    queries: "",
    requirement: "",
    budget: ""
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const businessTypes = [
    "Startup",
    "Small Business",
    "Mid-Size Company",
    "Enterprise",
    "Freelancer",
    "Agency",
    "Creator/Influencer",
    "Other"
  ];

  const budgetOptions = [
    "Under $500",
    "$500 - $1,000",
    "$1,000 - $2,500",
    "$2,500 - $5,000",
    "$5,000 - $10,000",
    "$10,000+",
    "Not sure yet"
  ];

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.businessType) newErrors.businessType = "Business Type is required";
    if (!formData.email.trim()) newErrors.email = "Email is required";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = "Valid email is required";
    if (!formData.whatsapp.trim()) newErrors.whatsapp = "WhatsApp number is required";
    if (!formData.queries.trim()) newErrors.queries = "Queries are required";
    if (!formData.requirement.trim()) newErrors.requirement = "Requirement is required";
    if (!formData.budget) newErrors.budget = "Budget is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setLoading(true);

    // Create WhatsApp message
    const message = `New Website Inquiry
Name: ${formData.name}
Business Type: ${formData.businessType}
Email: ${formData.email}
WhatsApp: ${formData.whatsapp}
Queries: ${formData.queries}
Requirement: ${formData.requirement}
Budget Recommended: ${formData.budget}`;

    // Encode the message for URL
    const encodedMessage = encodeURIComponent(message);
    const whatsappLink = `https://wa.me/919324318917?text=${encodedMessage}`;

    // Show success message
    setSubmitted(true);

    // Redirect to WhatsApp after a brief delay
    setTimeout(() => {
      window.open(whatsappLink, "_blank");
      setLoading(false);
    }, 500);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ""
      }));
    }
  };

  if (submitted) {
    return (
      <section id="inquiry" className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-2xl mx-auto text-center"
          >
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-[hsl(var(--primary))]/10 mb-6">
              <CheckCircle className="w-10 h-10 text-[hsl(var(--primary))]" />
            </div>
            <h2 className="text-4xl font-bold font-heading mb-4 text-gray-900">
              Opening WhatsApp…
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Your inquiry details are being sent to WhatsApp. If it doesn't open automatically, click the button below.
            </p>
            <Button
              onClick={() => window.open('https://wa.me/919324318917?text=' + encodeURIComponent(`New Website Inquiry
Name: ${formData.name}
Business Type: ${formData.businessType}
Email: ${formData.email}
WhatsApp: ${formData.whatsapp}
Queries: ${formData.queries}
Requirement: ${formData.requirement}
Budget Recommended: ${formData.budget}`), "_blank")}
              className="bg-[hsl(var(--primary))] text-black hover:bg-emerald-500 rounded-full px-8 py-4 font-bold text-lg inline-flex items-center gap-2"
            >
              Open WhatsApp <ArrowRight className="w-5 h-5" />
            </Button>
            <p className="text-sm text-gray-500 mt-8">
              You'll be redirected to WhatsApp where we can discuss your project details.
            </p>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section id="inquiry" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12 text-center"
          >
            <h2 className="text-4xl md:text-5xl font-bold font-heading mb-4 text-gray-900">
              Project Inquiry Form
            </h2>
            <p className="text-xl text-gray-600">
              Tell us about your project. We'll get back to you on WhatsApp with next steps and pricing.
            </p>
          </motion.div>

          <motion.form
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            onSubmit={handleSubmit}
            className="space-y-6 bg-gray-50 p-8 md:p-10 rounded-2xl border border-gray-200"
          >
            {/* Name */}
            <div>
              <label htmlFor="name" className="block text-sm font-semibold text-gray-900 mb-2">
                Your Name *
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="e.g., John Smith"
                className={`w-full px-4 py-3 rounded-lg border-2 transition-colors font-medium ${
                  errors.name 
                    ? "border-red-500 bg-red-50" 
                    : "border-gray-200 bg-white hover:border-gray-300 focus:border-[hsl(var(--primary))]"
                } outline-none`}
                data-testid="input-name"
              />
              {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
            </div>

            {/* Business Type */}
            <div>
              <label htmlFor="businessType" className="block text-sm font-semibold text-gray-900 mb-2">
                Business Type *
              </label>
              <select
                id="businessType"
                name="businessType"
                value={formData.businessType}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 rounded-lg border-2 transition-colors font-medium ${
                  errors.businessType 
                    ? "border-red-500 bg-red-50" 
                    : "border-gray-200 bg-white hover:border-gray-300 focus:border-[hsl(var(--primary))]"
                } outline-none`}
                data-testid="select-businessType"
              >
                <option value="">Select your business type</option>
                {businessTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
              {errors.businessType && <p className="text-red-500 text-sm mt-1">{errors.businessType}</p>}
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-semibold text-gray-900 mb-2">
                Contact Email *
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="your@email.com"
                className={`w-full px-4 py-3 rounded-lg border-2 transition-colors font-medium ${
                  errors.email 
                    ? "border-red-500 bg-red-50" 
                    : "border-gray-200 bg-white hover:border-gray-300 focus:border-[hsl(var(--primary))]"
                } outline-none`}
                data-testid="input-email"
              />
              {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
            </div>

            {/* WhatsApp Number */}
            <div>
              <label htmlFor="whatsapp" className="block text-sm font-semibold text-gray-900 mb-2">
                WhatsApp Number *
              </label>
              <input
                type="tel"
                id="whatsapp"
                name="whatsapp"
                value={formData.whatsapp}
                onChange={handleInputChange}
                placeholder="e.g., +91 9324318917"
                className={`w-full px-4 py-3 rounded-lg border-2 transition-colors font-medium ${
                  errors.whatsapp 
                    ? "border-red-500 bg-red-50" 
                    : "border-gray-200 bg-white hover:border-gray-300 focus:border-[hsl(var(--primary))]"
                } outline-none`}
                data-testid="input-whatsapp"
              />
              {errors.whatsapp && <p className="text-red-500 text-sm mt-1">{errors.whatsapp}</p>}
            </div>

            {/* Queries */}
            <div>
              <label htmlFor="queries" className="block text-sm font-semibold text-gray-900 mb-2">
                Your Queries / Questions *
              </label>
              <textarea
                id="queries"
                name="queries"
                value={formData.queries}
                onChange={handleInputChange}
                placeholder="Tell us what you're looking for..."
                rows={3}
                className={`w-full px-4 py-3 rounded-lg border-2 transition-colors font-medium resize-none ${
                  errors.queries 
                    ? "border-red-500 bg-red-50" 
                    : "border-gray-200 bg-white hover:border-gray-300 focus:border-[hsl(var(--primary))]"
                } outline-none`}
                data-testid="textarea-queries"
              />
              {errors.queries && <p className="text-red-500 text-sm mt-1">{errors.queries}</p>}
            </div>

            {/* Requirement */}
            <div>
              <label htmlFor="requirement" className="block text-sm font-semibold text-gray-900 mb-2">
                Project Requirements *
              </label>
              <textarea
                id="requirement"
                name="requirement"
                value={formData.requirement}
                onChange={handleInputChange}
                placeholder="Describe what you need - website, automation, features, etc..."
                rows={4}
                className={`w-full px-4 py-3 rounded-lg border-2 transition-colors font-medium resize-none ${
                  errors.requirement 
                    ? "border-red-500 bg-red-50" 
                    : "border-gray-200 bg-white hover:border-gray-300 focus:border-[hsl(var(--primary))]"
                } outline-none`}
                data-testid="textarea-requirement"
              />
              {errors.requirement && <p className="text-red-500 text-sm mt-1">{errors.requirement}</p>}
            </div>

            {/* Budget */}
            <div>
              <label htmlFor="budget" className="block text-sm font-semibold text-gray-900 mb-2">
                Budget Range *
              </label>
              <select
                id="budget"
                name="budget"
                value={formData.budget}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 rounded-lg border-2 transition-colors font-medium ${
                  errors.budget 
                    ? "border-red-500 bg-red-50" 
                    : "border-gray-200 bg-white hover:border-gray-300 focus:border-[hsl(var(--primary))]"
                } outline-none`}
                data-testid="select-budget"
              >
                <option value="">Select your budget range</option>
                {budgetOptions.map(budget => (
                  <option key={budget} value={budget}>{budget}</option>
                ))}
              </select>
              {errors.budget && <p className="text-red-500 text-sm mt-1">{errors.budget}</p>}
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-[hsl(var(--primary))] text-black hover:bg-emerald-500 disabled:opacity-70 disabled:cursor-not-allowed rounded-full py-4 font-bold text-lg mt-8 inline-flex items-center justify-center gap-2"
              data-testid="button-submit-inquiry"
            >
              {loading ? "Preparing..." : "Submit & Chat on WhatsApp"}
              <ArrowRight className="w-5 h-5" />
            </Button>

            <p className="text-center text-sm text-gray-500 mt-4">
              Your information will be securely sent to our WhatsApp. We'll respond within 24 hours.
            </p>
          </motion.form>
        </div>
      </div>
    </section>
  );
}
