import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

// Project images from public folder
const cosmeticSurgery = "/IMG_20251121_101655_405_1765006368181.jpg";
const leversiClothing = "/IMG_20251121_101652_867_1765006368337.jpg";
const cigatiSolutions = "/IMG_20251121_101657_076_1765006368402.jpg";
const bambooHuts = "/IMG_20251121_101809_334_1765006368460.jpg";
const procutCarpentry = "/IMG_20251121_101919_883_1765006368521.jpg";
const healthyLife = "/IMG_20251206_134148_331_1765008736564.jpg";
const miniSingh = "/IMG_20251207_163211_652_1765106002333.jpg";
const whollyBeing = "/IMG_20251207_163124_271_1765106002435.jpg";
const veecloset = "/IMG_20251207_163214_253_1765106002469.jpg";

const projects = [
  {
    title: "Cosmetic Surgery Website",
    category: "Website Development",
    image: cosmeticSurgery,
    problem: "Medical clinic needed a professional online presence to build trust.",
    solution: "Built a modern, responsive website showcasing services with patient testimonials.",
    result: "30% increase in patient inquiries within 2 months.",
    link: "https://kraftmed.life"
  },
  {
    title: "Leversi Clothing Brand",
    category: "E-commerce Website",
    image: leversiClothing,
    problem: "Fashion startup struggled with low online sales and visibility.",
    solution: "Created a stunning e-commerce store with product filtering and secure payments.",
    result: "2.5x increase in online sales, 40% cart conversion rate.",
    link: "https://itsleversi.com"
  },
  {
    title: "Cigati Solutions Safeguard",
    category: "SaaS Website",
    image: cigatiSolutions,
    problem: "Tech company needed to explain complex data backup solutions simply.",
    solution: "Designed an intuitive website with clear product value props and CTAs.",
    result: "50+ qualified leads per month, improved brand credibility.",
    link: "https://www.cigatisolutions.com/"
  },
  {
    title: "Bamboo Huts Decor",
    category: "Website Development",
    image: bambooHuts, 
    problem: "Eco-friendly manufacturer had no digital presence to reach customers.",
    solution: "Built a beautiful portfolio site showcasing bamboo products and craftsmanship.",
    result: "Landed 15+ B2B orders, expanded business reach nationally.",
    link: "https://bamboohutsdecor.com"
  },
  {
    title: "Procut Carpentry Services",
    category: "Website Development",
    image: procutCarpentry,
    problem: "Local carpentry business lost customers due to outdated online presence.",
    solution: "Created modern portfolio with project gallery and instant quote system.",
    result: "Booked 20+ projects, became top local search result.",
    link: "https://procutcarpentry.com.au/"
  },
  {
    title: "Healthy Life Blog & Community",
    category: "Website Development",
    image: healthyLife,
    problem: "Health influencer needed platform for content, courses, and community.",
    solution: "Built feature-rich wellness website with blog, courses, and membership.",
    result: "2,000+ active members, generating $5K/month in course sales.",
    link: "https://healthyharsh.com"
  },
  {
    title: "Mini Singh Cloths",
    category: "E-commerce Fashion",
    image: miniSingh,
    problem: "Fashion brand needed a modern e-commerce platform to showcase collections.",
    solution: "Created elegant e-commerce store with category filters, cart system, and checkout.",
    result: "Increased online orders by 150%, improved customer engagement.",
    link: "https://minisingh.com"
  },
  {
    title: "Wholly Being - Tea Products",
    category: "E-commerce Store",
    image: whollyBeing,
    problem: "Organic tea brand struggled to reach customers online and showcase products.",
    solution: "Built wellness-focused e-commerce site with product catalog and subscriptions.",
    result: "Launched subscription model, 200+ recurring customers.",
    link: "https://whollybeing.in/"
  },
  {
    title: "Veecloset - Luxury Fashion",
    category: "E-commerce Fashion",
    image: veecloset,
    problem: "High-end fashion brand needed premium online presence.",
    solution: "Designed luxury e-commerce platform with advanced filtering and smooth checkout.",
    result: "High conversion rate, became top online fashion brand in category.",
    link: "https://veecloset.co.in/"
  }
];

export function Projects() {
  return (
    <section id="work" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-bold font-heading mb-6 text-gray-900">
              Projects
            </h2>
            <p className="text-xl text-gray-600">
              Real businesses, real results. Successful website projects showcasing web development expertise and design capability.
            </p>
            <span className="hidden">Website portfolio | Web development case studies | Client projects | Website design examples | Professional websites</span>
          </div>
          <Button variant="outline" className="rounded-full hidden md:flex mt-6 md:mt-0">
            View All Case Studies <ArrowUpRight className="ml-2 w-4 h-4" />
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group cursor-pointer flex flex-col h-full"
            >
              <div className="relative overflow-hidden rounded-2xl mb-6 aspect-[4/3] w-full bg-gray-100">
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors z-10 duration-500" />
                <img 
                  src={project.image} 
                  alt={`${project.title} - ${project.category} website project showcase`}
                  loading="lazy"
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              
              <div className="flex flex-col grow">
                <div className="mb-3">
                  <Badge variant="secondary" className="rounded-md bg-gray-100 hover:bg-gray-200 text-gray-600 font-medium">
                    {project.category}
                  </Badge>
                </div>
                
                <h3 className="text-2xl font-bold text-gray-900 mb-2 group-hover:text-[hsl(var(--primary))] transition-colors">
                  {project.title}
                </h3>
                
                <p className="text-gray-600 mb-6 leading-relaxed line-clamp-2">
                  {project.solution}
                </p>
                
                <div className="mt-auto">
                   <Button 
                     variant="outline" 
                     className="rounded-full w-full border-gray-300 hover:bg-black hover:text-white transition-colors"
                     onClick={() => window.open(project.link, '_blank')}
                     data-testid={`button-view-${project.title.toLowerCase().replace(/\s+/g, '-')}`}
                   >
                     View Live <ArrowUpRight className="ml-2 w-4 h-4" />
                   </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
