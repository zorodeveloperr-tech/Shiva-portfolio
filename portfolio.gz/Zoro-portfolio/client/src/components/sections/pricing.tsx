import { useRef, useState } from "react";
import { Check, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const tiers = [
  {
    name: "Landing Page Starter",
    description: "Essential online presence with a clean, high-impact single landing page built to convert.",
    features: [
      "Modern single-page design",
      "Fully Responsive (Mobile/Tablet/Desktop)",
      "SEO-Ready structure",
      "Clear headline & CTAs",
      "Basic contact form",
      "Fast loading speed"
    ],
    cta: "Contact to Get This Plan",
  },
  {
    name: "Business Website Essentials",
    description: "Professional growth foundation with everything a growing business needs.",
    features: [
      "3–5 page business website",
      "Fully Responsive Design",
      "Brand-aligned layout",
      "Hosting & Domain support",
      "Lead capture forms",
      "SEO-Optimized Structure",
      "Lightweight performance"
    ],
    cta: "Contact to Get This Plan",
  },
  {
    name: "Growth Website + Smart Automations",
    description: "Premium website designed for growth with automated workflows that scale.",
    features: [
      "Everything in Business Essentials",
      "5–7 page personalized website",
      "Lead capture funnel setup",
      "AI-powered auto-replies",
      "Basic CRM automation",
      "Enhanced SEO Optimization",
      "Priority performance tuning"
    ],
    cta: "Contact to Get This Plan",
    popular: true,
  },
  {
    name: "Custom Website + Advanced AI Automation System",
    description: "End-to-end digital transformation with fully customized, automation-driven systems.",
    features: [
      "Fully custom design system",
      "Unlimited pages (as needed)",
      "Advanced AI workflows & logic",
      "Multi-step lead funnels",
      "CRM & API integrations",
      "WhatsApp Business API setup",
      "Advanced Technical SEO",
      "Priority Support"
    ],
    cta: "Contact to Get This Plan",
  }
];

export function Pricing() {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const checkScroll = () => {
    const container = scrollContainerRef.current;
    if (container) {
      setCanScrollLeft(container.scrollLeft > 0);
      setCanScrollRight(
        container.scrollLeft < container.scrollWidth - container.clientWidth - 10
      );
    }
  };

  const scroll = (direction: 'left' | 'right') => {
    const container = scrollContainerRef.current;
    if (container) {
      const cardWidth = container.querySelector('[class*="min-w"]')?.clientWidth || container.clientWidth;
      const scrollAmount = cardWidth + 24; // card width + gap
      if (direction === 'left') {
        container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
      } else {
        container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
      }
      setTimeout(checkScroll, 300);
    }
  };

  return (
    <section id="pricing" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold font-heading mb-6 text-gray-900">
            Pricing Plans
          </h2>
          <p className="text-xl text-gray-600">
            Transparent, premium pricing for every stage of your business growth. Swipe or scroll to explore.
          </p>
        </motion.div>

        {/* Scroll Container with Navigation */}
        <div className="relative">
          {/* Left Scroll Button */}
          {canScrollLeft && (
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              onClick={() => scroll('left')}
              className="absolute left-0 top-1/2 -translate-y-1/2 z-20 hidden lg:flex items-center justify-center w-12 h-12 rounded-full bg-white shadow-lg border border-gray-200 hover:shadow-xl transition-all"
              data-testid="button-scroll-left"
            >
              <ChevronLeft className="w-6 h-6 text-gray-700" />
            </motion.button>
          )}

          {/* Right Scroll Button */}
          {canScrollRight && (
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              onClick={() => scroll('right')}
              className="absolute right-0 top-1/2 -translate-y-1/2 z-20 hidden lg:flex items-center justify-center w-12 h-12 rounded-full bg-white shadow-lg border border-gray-200 hover:shadow-xl transition-all"
              data-testid="button-scroll-right"
            >
              <ChevronRight className="w-6 h-6 text-gray-700" />
            </motion.button>
          )}

          {/* Horizontal Scroll Container */}
          <div
            ref={scrollContainerRef}
            onScroll={checkScroll}
            className="flex gap-6 overflow-x-auto scroll-smooth snap-x snap-mandatory pb-4"
            style={{
              scrollBehavior: 'smooth',
              WebkitOverflowScrolling: 'touch',
              scrollPaddingLeft: '24px',
            }}
          >
            {tiers.map((tier, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="min-w-[calc(100vw-48px)] md:min-w-[calc(100vw-240px)] snap-start flex-shrink-0"
              >
                <div
                  className={`h-full rounded-2xl p-8 transition-all duration-300 flex flex-col border ${
                    tier.popular
                      ? "bg-gradient-to-br from-gray-900 to-gray-800 border-[hsl(var(--primary))] shadow-2xl"
                      : "bg-white border-gray-200 shadow-lg hover:shadow-2xl hover:border-gray-300"
                  }`}
                >
                  {/* Popular Badge */}
                  {tier.popular && (
                    <div className="flex justify-center mb-4">
                      <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[hsl(var(--primary))] text-black text-sm font-bold">
                        ⭐ MOST POPULAR
                      </span>
                    </div>
                  )}

                  {/* Title & Description */}
                  <h3 className={`text-2xl font-bold font-heading mb-2 ${tier.popular ? "text-white" : "text-gray-900"}`}>
                    {tier.name}
                  </h3>
                  <p className={`text-sm leading-relaxed mb-6 ${tier.popular ? "text-gray-300" : "text-gray-600"}`}>
                    {tier.description}
                  </p>

                  {/* Features List */}
                  <div className="flex-1 mb-8">
                    <ul className="space-y-3">
                      {tier.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <Check className={`w-5 h-5 shrink-0 mt-0.5 ${tier.popular ? "text-[hsl(var(--primary))]" : "text-[hsl(var(--primary))]"}`} />
                          <span className={`text-sm ${tier.popular ? "text-gray-200" : "text-gray-700"}`}>
                            {feature}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* CTA Button */}
                  <Button
                    className={`w-full rounded-xl py-3 font-bold text-base transition-all ${
                      tier.popular
                        ? "bg-[hsl(var(--primary))] text-black hover:bg-emerald-500"
                        : "bg-[hsl(var(--primary))] text-black hover:bg-emerald-500"
                    }`}
                    onClick={() => document.getElementById('inquiry')?.scrollIntoView({ behavior: 'smooth' })}
                    data-testid={`button-pricing-${tier.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {tier.cta}
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* CTA Footer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-center mt-16"
        >
          <p className="text-gray-600 text-lg">
            Looking for something completely custom?
            <a
              href="https://wa.me/919324318917"
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold text-[hsl(var(--primary))] hover:underline ml-2 inline-block"
              data-testid="link-custom-solution"
            >
              Let's chat on WhatsApp
            </a>
          </p>
        </motion.div>
      </div>
    </section>
  );
}
