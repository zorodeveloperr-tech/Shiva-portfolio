import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export function ContactCTA() {
  return (
    <section id="contact" className="py-24 bg-[hsl(var(--primary))] overflow-hidden relative">
      {/* Abstract decorative circles */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-black/5 rounded-full blur-3xl translate-x-1/3 translate-y-1/3" />

      <div className="container mx-auto px-6 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="text-5xl md:text-7xl font-bold font-heading mb-8 text-black leading-tight">
            One step away from growing your business.
          </h2>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              className="bg-black text-white hover:bg-gray-900 text-lg rounded-full px-10 py-8 h-auto shadow-xl hover:shadow-2xl transition-all transform hover:-translate-y-1"
              onClick={() => window.location.href = 'mailto:zoro.developerr@gmail.com'}
            >
              Contact Now <ArrowRight className="ml-2" />
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
