import { motion } from "framer-motion";
import { MessageCircle, ArrowRight } from "lucide-react";

export function AboutMe() {
  return (
    <section id="about-me" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-5xl md:text-6xl font-bold font-heading mb-8 text-gray-900">
              About Me
            </h2>
            
            <p className="text-xl md:text-2xl text-gray-600 leading-relaxed mb-12 max-w-2xl mx-auto">
              I'm <span className="font-bold text-gray-900">Shiva (Zoro Developer)</span>. I build modern websites and simple AI automations for businesses and creators around the world. My focus is clean design, fast delivery, and websites that actually help you grow.
            </p>

            <div className="bg-gradient-to-r from-[hsl(var(--primary))]/10 to-blue-500/10 rounded-2xl p-8 md:p-12 mb-12 border border-gray-200">
              <p className="text-lg text-gray-700 leading-relaxed">
                Ready to get your website? Message me and I'll create a simple plan and timeline for your project.
              </p>
            </div>

            <motion.a
              href="https://wa.me/919324318917"
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="inline-flex items-center gap-3 bg-[hsl(var(--primary))] text-black font-bold px-8 py-4 rounded-full hover:bg-emerald-500 transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl"
              data-testid="button-whatsapp"
            >
              <MessageCircle className="w-5 h-5" />
              Chat With Me on WhatsApp
              <ArrowRight className="w-5 h-5" />
            </motion.a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
