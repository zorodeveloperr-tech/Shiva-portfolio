import { 
  Code, 
  Cpu, 
  MessageSquare, 
  Zap, 
} from "lucide-react";
import { motion } from "framer-motion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const services = [
  {
    icon: <Code className="w-10 h-10 text-[hsl(var(--primary))]" />,
    title: "Landing Page Starter",
    description: "Perfect for fast launches and personal brands.",
    points: ["Single-page high-conversion design", "Mobile-first & SEO friendly", "Fast delivery"]
  },
  {
    icon: <Zap className="w-10 h-10 text-blue-500" />,
    title: "Business Website Essentials",
    description: "Complete professional presence for growing companies.",
    points: ["3-5 page responsive website", "Brand-aligned design", "Contact & lead forms"]
  },
  {
    icon: <MessageSquare className="w-10 h-10 text-purple-500" />,
    title: "Growth Website + Automations",
    description: "Scale your business with smart systems.",
    points: ["5-7 pages with custom features", "Lead capture funnels", "Auto-reply & basic CRM"]
  },
  {
    icon: <Cpu className="w-10 h-10 text-yellow-500" />,
    title: "Custom Website + AI System",
    description: "The ultimate solution for automation-heavy needs.",
    points: ["Fully custom design system", "Advanced AI workflows", "Complete business integration"]
  }
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="mb-16 max-w-3xl">
          <h2 className="text-4xl md:text-5xl font-bold font-heading mb-6 text-gray-900">
            Our Services
          </h2>
          <p className="text-xl text-gray-600">
            From simple landing pages to complex AI-driven systems, we build fully responsive solutions tailored to your goals.
          </p>
          <span className="hidden">Website development services | Website redesign | AI automation solutions | Business process automation | WordPress development | AI chatbots</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="h-full border-none shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white group overflow-hidden relative p-2">
                <div className="absolute top-0 left-0 w-1 h-full bg-gray-100 group-hover:bg-[hsl(var(--primary))] transition-colors duration-300" />
                <CardHeader>
                  <div className="mb-4 p-3 rounded-xl bg-gray-50 w-fit group-hover:scale-110 transition-transform duration-300">
                    {service.icon}
                  </div>
                  <CardTitle className="text-2xl font-bold">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base leading-relaxed text-gray-600 mb-4">
                    {service.description}
                  </CardDescription>
                  <ul className="space-y-2">
                    {service.points.map((point, i) => (
                      <li key={i} className="flex items-center text-sm text-gray-500">
                        <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--primary))] mr-2" />
                        {point}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
