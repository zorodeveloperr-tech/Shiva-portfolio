import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Hero } from "@/components/sections/hero";
import { About } from "@/components/sections/about";
import { Services } from "@/components/sections/services";
import { Projects } from "@/components/sections/projects";
import { InquiryForm } from "@/components/sections/inquiry-form";
import { Process } from "@/components/sections/process";
import { Pricing } from "@/components/sections/pricing";
import { FAQ } from "@/components/sections/faq";
import { BookCallCTA } from "@/components/sections/book-call-cta";

export default function Home() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-[hsl(var(--primary))] selection:text-black">
      <Navbar />
      <main>
        <Hero />
        <Services />
        <Pricing />
        <Projects />
        <About />
        <Process />
        <FAQ />
        <InquiryForm />
        <BookCallCTA />
      </main>
      <Footer />
    </div>
  );
}
